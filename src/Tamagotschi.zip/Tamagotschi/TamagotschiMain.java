package Tamagotschi;

public class TamagotschiMain {
  public static void main(String[] args) {

    SpielController spielController = new SpielController();
    spielController.run();
  }
}
